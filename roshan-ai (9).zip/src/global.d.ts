/// <reference types="vite/client" />
declare module 'react-quill-new';
